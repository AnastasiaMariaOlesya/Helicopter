﻿//using MachineLearningLib;
//using ru.aryumin.MachineLearningLib;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helicopter
{
    public class Algorithm
    {
        //A, B, Q, S, delta_V - известно
        
        
        //решение уравнения риккати
        //найти С = B * Q^-1 * B_transp
        //-A_transp * P - P * A + P * С * P - S = 0
        //найти P
        
        
        
        
        //найти u = Q^-1 * B_transp * P
        
        
        
        
        //решить ДУ методом рунге-кутты
        //x. = A * x + B * u
        //=> x = .....
        //построить график x(t)

        



    }
}
