﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helicopter
{
    public class Algorithm
    {
        //A, B, Q, S, delta_V - известно

        //Matrix A
        double a11, a12, a13, a14, a15, a16, a17, a18,
               a21, a22, a23, a24, a25, a26, a27, a28,
               a31, a32, a33, a34, a35, a36, a37, a38,
               a41, a42, a43, a44, a45, a46, a47, a48,
               a51, a52, a53, a54, a55, a56, a57, a58,
               a61, a62, a63, a64, a65, a66, a67, a68,
               a71, a72, a73, a74, a75, a76, a77, a78,
               a81, a82, a83, a84, a85, a86, a87, a88;
        
        //Matrix B
        double b11, b12, b13, b14,
               b21, b22, b23, b24,
               b31, b32, b33, b34,
               b41, b42, b43, b44,
               b51, b52, b53, b54,
               b61, b62, b63, b64,
               b71, b72, b73, b74,
               b81, b82, b83, b84;

        //A 8x8
        public void InitMatrixA(double a11_, double a12_, double a13_, double a14_, double a15_, double a16_, double a17_, double a18_,
                               double a21_, double a22_, double a23_, double a24_, double a25_, double a26_, double a27_, double a28_,
                               double a31_, double a32_, double a33_, double a34_, double a35_, double a36_, double a37_, double a38_,
                               double a41_, double a42_, double a43_, double a44_, double a45_, double a46_, double a47_, double a48_,
                               double a51_, double a52_, double a53_, double a54_, double a55_, double a56_, double a57_, double a58_,
                               double a61_, double a62_, double a63_, double a64_, double a65_, double a66_, double a67_, double a68_,
                               double a71_, double a72_, double a73_, double a74_, double a75_, double a76_, double a77_, double a78_,
                               double a81_, double a82_, double a83_, double a84_, double a85_, double a86_, double a87_, double a88_)
        {
            a11 = a11_; a12 = a12_; a13 = a13_; a14 = a14_; a15 = a15_; a16 = a16_; a17 = a17_; a18 = a18_;
            a21 = a21_; a22 = a22_; a23 = a23_; a24 = a24_; a25 = a25_; a26 = a26_; a27 = a27_; a28 = a28_;
            a31 = a31_; a32 = a32_; a33 = a33_; a34 = a34_; a35 = a35_; a36 = a36_; a37 = a37_; a38 = a38_;
            a41 = a41_; a42 = a42_; a43 = a43_; a44 = a44_; a45 = a45_; a46 = a46_; a47 = a47_; a48 = a48_;
            a51 = a51_; a52 = a52_; a53 = a53_; a54 = a54_; a55 = a55_; a56 = a56_; a57 = a57_; a58 = a58_;
            a61 = a61_; a62 = a62_; a63 = a63_; a64 = a64_; a65 = a65_; a66 = a66_; a67 = a67_; a68 = a68_;
            a71 = a71_; a72 = a72_; a73 = a73_; a74 = a74_; a75 = a75_; a76 = a76_; a77 = a77_; a78 = a78_;
            a81 = a81_; a82 = a82_; a83 = a83_; a84 = a84_; a85 = a85_; a86 = a86_; a87 = a87_; a88 = a88_;
        }

        //B 8x4
        public void InitMatrixB(double b11_, double b12_, double b13_, double b14_, 
                               double b21_, double b22_, double b23_, double b24_, 
                               double b31_, double b32_, double b33_, double b34_, 
                               double b41_, double b42_, double b43_, double b44_, 
                               double b51_, double b52_, double b53_, double b54_, 
                               double b61_, double b62_, double b63_, double b64_, 
                               double b71_, double b72_, double b73_, double b74_, 
                               double b81_, double b82_, double b83_, double b84_)
        {
            b11 = b11_; b12 = b12_; b13 = b13_; b14 = b14_; 
            b21 = b21_; b22 = b22_; b23 = b23_; b24 = b24_; 
            b31 = b31_; b32 = b32_; b33 = b33_; b34 = b34_; 
            b41 = b41_; b42 = b42_; b43 = b43_; b44 = b44_;
            b51 = b51_; b52 = b52_; b53 = b53_; b54 = b54_;
            b61 = b61_; b62 = b62_; b63 = b63_; b64 = b64_;
            b71 = b71_; b72 = b72_; b73 = b73_; b74 = b74_;
            b81 = b81_; b82 = b82_; b83 = b83_; b84 = b84_;
        }

    }
}
