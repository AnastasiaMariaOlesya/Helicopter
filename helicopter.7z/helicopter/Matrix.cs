﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace helicopter
{
    public class Matrix
    {
        public double[,] matrixBase;

        public Matrix(double[,] matrixBase)
        {
            this.matrixBase = matrixBase;
        }


        //-------------------------------------------------------------------------------------------------
        //Сумма матриц
        public static Matrix SumMatr(Matrix matrixA, Matrix matrixB)
        {
            if (matrixA.matrixBase.GetLength(0) != matrixB.matrixBase.GetLength(0) || matrixA.matrixBase.GetLength(1) != matrixB.matrixBase.GetLength(1))
                throw new FormatException("Разное кол-во стр или стб!");

            Matrix matrixC = new Matrix(new double[matrixA.matrixBase.GetLength(0), matrixB.matrixBase.GetLength(1)]);
            for(int row = 0; row < matrixA.matrixBase.GetLength(0); row++)
            {
                for(int column = 0; column < matrixA.matrixBase.GetLength(1); column++)
                {
                    matrixC.matrixBase[row, column] = matrixA.matrixBase[row, column] + matrixB.matrixBase[row, column];
                }
            }

            return matrixC;
        }


        //-------------------------------------------------------------------------------------------------
        //Вычитание матриц
        public static Matrix SubstractMatr(Matrix matrixA, Matrix matrixB)
        {
            if (matrixA.matrixBase.GetLength(0) != matrixB.matrixBase.GetLength(0) || matrixA.matrixBase.GetLength(1) != matrixB.matrixBase.GetLength(1))
                throw new FormatException("Разное кол-во стр или стб!");

            Matrix matrixC = new Matrix(new double[matrixA.matrixBase.GetLength(0), matrixB.matrixBase.GetLength(1)]);
            for (int row = 0; row < matrixA.matrixBase.GetLength(0); row++)
            {
                for (int column = 0; column < matrixA.matrixBase.GetLength(1); column++)
                {
                    matrixC.matrixBase[row, column] = matrixA.matrixBase[row, column] - matrixB.matrixBase[row, column];
                }
            }

            return matrixC;
        }


        //-------------------------------------------------------------------------------------------------
        //Умножение матриц
        public static Matrix MultiplyMatr(Matrix matrixA, Matrix matrixB)
        {
            if (matrixA.matrixBase.GetLength(1) != matrixB.matrixBase.GetLength(0))
                throw new FormatException("Матрицы не согласованы!");

            Matrix matrixC = new Matrix(new double[matrixA.matrixBase.GetLength(0), matrixB.matrixBase.GetLength(1)]);
            for(int i = 0; i < matrixB.matrixBase.GetLength(1); i++)
            {
                for(int j = 0; j < matrixA.matrixBase.GetLength(0); j++)
                {
                    double result = 0;
                    for(int k = 0; k < matrixA.matrixBase.GetLength(1); k++)
                    {
                        result += matrixA.matrixBase[j, k] * matrixB.matrixBase[k, i];
                    }
                    matrixC.matrixBase[j, i] = result;
                }
            }

            return matrixC;
        }


        //-------------------------------------------------------------------------------------------------
        //Умножение матрицы на число
        public Matrix MultiplyToScalar(double scalar)
        {
            Matrix m = new Matrix(this.matrixBase);
            for (int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                for (int j = 0; j < this.matrixBase.GetLength(1); j++)
                {
                    m.matrixBase[i, j] = m.matrixBase[i, j] * scalar;
                }
            }

            return m;
        }


        //-------------------------------------------------------------------------------------------------
        //Транспонирование матрицы
        public Matrix Transpose()
        {
            Matrix newMatrix = new Matrix(new double[this.matrixBase.GetLength(1), this.matrixBase.GetLength(0)]);

            for (int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                for (int j = 0; j < this.matrixBase.GetLength(1); j++)
                {
                    newMatrix.matrixBase[j, i] = this.matrixBase[i, j];
                }
            }

            return newMatrix;

        }


        //-------------------------------------------------------------------------------------------------
        //Определитель матрицы
        public double Det()
        {
            if (this.matrixBase.GetLength(0) != this.matrixBase.GetLength(1))
                throw new InvalidOperationException("Матрица не квадратная!");
            
            //для матрицы 2х2
            if(this.matrixBase.GetLength(0) == 2)
            {
                return this.matrixBase[0, 0] * this.matrixBase[1, 1]
                    - this.matrixBase[0, 1] * this.matrixBase[1, 0];
            }



            //
            double[,] extendedMatrixBase = new double[this.matrixBase.GetLength(0), 
                this.matrixBase.GetLength(1) + this.matrixBase.GetLength(1) - 1];

            //
            for(int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                for(int j = 0; j < this.matrixBase.GetLength(1); j++)
                {
                    extendedMatrixBase[i, j] = this.matrixBase[i, j];
                }
            }

            //
            for(int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                for(int j = this.matrixBase.GetLength(1); j < extendedMatrixBase.GetLength(1); j++)
                {
                    extendedMatrixBase[i, j] = this.matrixBase[i, j - this.matrixBase.GetLength(0)];
                }
            }

            Matrix extendedMatrix = new Matrix(extendedMatrixBase);

            //
            double determinant = 0.0;

            //
            double sumsResult = 0.0;
            for(int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                int row = 0;
                int column = i;

                double diagonalResult = 1.0;
                for (int j = 0; j < this.matrixBase.GetLength(0); j++, row++, column++)
                {
                    diagonalResult *= extendedMatrix.matrixBase[row,column];
                }
                sumsResult += diagonalResult;
            }

            //
            double substractionsResult = 0.0;
            for (int i = 0; i < this.matrixBase.GetLength(0); i++)
            {
                int row = 0;
                int column = extendedMatrix.matrixBase.GetLength(1) - 1 - i;

                double diagonalResult = 1.0;
                for(int j = 0; j < this.matrixBase.GetLength(0); j++, row++, column--)
                {
                    diagonalResult *= extendedMatrix.matrixBase[row, column];
                }
                substractionsResult += diagonalResult;
            }

            determinant = sumsResult - substractionsResult;

            return determinant;
        }


        //-------------------------------------------------------------------------------------------------
        //Обращение матрицы
        public Matrix Invert()
        {
            Matrix invertedMatrix;

            if (this.Det() != 0)
            {
                //
                Matrix matrixOfMinors = new Matrix(new double[matrixBase.GetLength(0), matrixBase.GetLength(1)]);

                for (int row = 0; row < matrixBase.GetLength(0); row++)
                {
                    for(int column= 0; column < matrixBase.GetLength(1); column++)
                    {
                        double[,] subMArrBase = new double[matrixBase.GetLength(0)-1,matrixBase.GetLength(1)-1];
                        Matrix subMatrix = new Matrix(subMArrBase);

                        int subMRow = 0;
                        for(int r = 0; r < matrixBase.GetLength(0); r++)
                        {
                            if (row == r)
                                continue;
                            int subMColumn = 0;
                            for (int c = 0; c < matrixBase.GetLength(1); c++)
                            {
                                if (column == c)
                                    continue;

                                subMArrBase[subMRow, subMColumn] = this.matrixBase[r, c];
                                subMColumn++;
                            }
                            subMRow++;
                        }

                        matrixOfMinors.matrixBase[row, column] = subMatrix.Det();
                    }
                }

                //
                int rowStartMultiplier;
                for(int i = 0; i < matrixOfMinors.matrixBase.GetLength(0); i++)
                {
                    if (i % 2 == 0)
                        rowStartMultiplier = 1;
                    else
                        rowStartMultiplier = -1;

                    for(int j = 0; j < matrixOfMinors.matrixBase.GetLength(1); j++)
                    {
                        matrixOfMinors.matrixBase[i, j] *= rowStartMultiplier;
                        //swap
                        rowStartMultiplier *= -1;
                    }
                }

                //
                double determinant = this.Det();
                Matrix transposed = matrixOfMinors.Transpose();
                invertedMatrix = transposed.MultiplyToScalar(1 / determinant);

            }
            else
                throw new InvalidOperationException("Матрица не обратима!");

            return invertedMatrix;
        }

    }
}
