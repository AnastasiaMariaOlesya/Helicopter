﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helicopter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitDataGridView();
            
        }

        private void InitDataGridView()
        {
            //Матрица S
            dataGridView1.RowCount = 8;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (i == j)
                    {
                        dataGridView1.Rows[i].Cells[j].Value = "1";
                    }
                    else
                    {
                        dataGridView1.Rows[i].Cells[j].Value = "0";
                    }
                }
            }

            //Матрица Q
            dataGridView2.RowCount = 4;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (i == j)
                    {
                        dataGridView2.Rows[i].Cells[j].Value = "1";
                    }
                    else
                    {
                        dataGridView2.Rows[i].Cells[j].Value = "0";
                    }
                }
            }

        }
        
        //кнопка получить ответ
        private void button1_Click(object sender, EventArgs e)
        {
            double[,] a = new double[2, 2];
            a[0, 0] = 2;
            a[0, 1] = 1;
            a[1, 0] = 1;
            a[1, 1] = 2;
            

            double[,] b = new double[2, 2];
            b[0, 0] = 100;
            b[0, 1] = 1;
            b[1, 1] = 100;
            b[1, 0] = 1;
         

            double[,] c = new double[2, 2];
          
            Matrix matrixA = new Matrix(a);
            Matrix matrixB = new Matrix(b);
            Matrix matrixC = new Matrix(c);

            //matrixA.Invert();
            Matrix inverted = matrixA.Invert();
           // matrixC = Matrix.SumMatr(matrixA, matrixB);

            dataGridView2.Rows[0].Cells[0].Value = inverted.matrixBase[0, 0];
            dataGridView2.Rows[1].Cells[0].Value = inverted.matrixBase[1, 0];
            dataGridView2.Rows[0].Cells[1].Value = inverted.matrixBase[0, 1];
            dataGridView2.Rows[1].Cells[1].Value = inverted.matrixBase[1, 1];

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }














    }
}
