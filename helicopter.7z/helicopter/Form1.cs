﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace helicopter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitDataGridView();
            
        }

        private void InitDataGridView()
        {
            //Матрица S
            dataGridView1.RowCount = 8;
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if (i == j)
                    {
                        dataGridView1.Rows[i].Cells[j].Value = "1";
                    }
                    else
                    {
                        dataGridView1.Rows[i].Cells[j].Value = "0";
                    }
                }
            }

            //Матрица Q
            dataGridView2.RowCount = 4;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (i == j)
                    {
                        dataGridView2.Rows[i].Cells[j].Value = "1";
                    }
                    else
                    {
                        dataGridView2.Rows[i].Cells[j].Value = "0";
                    }
                }
            }

            //начальное условие х
            dataGridView3.RowCount = 8;
            dataGridView3.Rows[0].Cells[0].Value = "x00";
            dataGridView3.Rows[1].Cells[0].Value = "x01";
            dataGridView3.Rows[2].Cells[0].Value = "x02";
            dataGridView3.Rows[3].Cells[0].Value = "x03";
            dataGridView3.Rows[4].Cells[0].Value = "x04";
            dataGridView3.Rows[5].Cells[0].Value = "x05";
            dataGridView3.Rows[6].Cells[0].Value = "x06";
            dataGridView3.Rows[7].Cells[0].Value = "x07";



            dataGridView3.Rows[0].Cells[1].Value = "-0,2";
            dataGridView3.Rows[1].Cells[1].Value = "-0,15";
            dataGridView3.Rows[2].Cells[1].Value = "-0,1";
            dataGridView3.Rows[3].Cells[1].Value = "-0,05";
            dataGridView3.Rows[4].Cells[1].Value = "0,05";
            dataGridView3.Rows[5].Cells[1].Value = "0,1";
            dataGridView3.Rows[6].Cells[1].Value = "0,15";
            dataGridView3.Rows[7].Cells[1].Value = "0,2";
        }







        double[] f(double[] X, Matrix A_Bu)
        {
            var N = X.Length;
            double[] v = new double[N];
            for (int i = 0; i < N; i++)
            {
                var s = 0.0;
                for (int j = 0; j < N; j++)
                    s += A_Bu.matrixBase[i, j] * X[j];
                v[i] = s;
                //v[i] = 1;
            }
            return v;
        }

        double[] V_sV(double[] x, double la, double[] y)
        {
            var N = x.Length;
            double[] v = new double[N];
            for (int i = 0; i < N; i++)
            {
                v[i] = x[i] + la * y[i];
            }
            return v;
        }

        int rkDataLen = 0;
        double[,] rkData;

        //кнопка получить ответ
        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                //начальные условия
                double[,] x0 = new double[8, 1];

                x0[0, 0] = Convert.ToDouble(dataGridView3.Rows[0].Cells[1].Value);
                x0[1, 0] = Convert.ToDouble(dataGridView3.Rows[1].Cells[1].Value);
                x0[2, 0] = Convert.ToDouble(dataGridView3.Rows[2].Cells[1].Value);
                x0[3, 0] = Convert.ToDouble(dataGridView3.Rows[3].Cells[1].Value);
                x0[4, 0] = Convert.ToDouble(dataGridView3.Rows[4].Cells[1].Value);
                x0[5, 0] = Convert.ToDouble(dataGridView3.Rows[5].Cells[1].Value);
                x0[6, 0] = Convert.ToDouble(dataGridView3.Rows[6].Cells[1].Value);
                x0[7, 0] = Convert.ToDouble(dataGridView3.Rows[7].Cells[1].Value);
    
                //матрица Q
                double[,] q = new double[4, 4];
                for (int i = 0; i < 4; i++)
                {
                    for (int j = 0; j < 4; j++)
                    {
                        if (i == j)
                        {
                            q[i, j] = 1;
                        }
                        else
                        {
                            q[i, j] = 0;
                        }
                    }
                }
                Matrix matrixQ = new Matrix(q);

                // матрица А
                double[,] a = new double[8, 8];
                //for (int i = 0; i < 8; ++ i) a[i, 0] = 1;
                a[0, 0] = -0.0199; a[0, 1] = 0.0215; a[0, 2] = 0.6674; a[0, 3] = -9.7837; a[0, 4] = -0.0205; a[0, 5] = -0.1600; a[0, 6] = 0.0000; a[0, 7] = 0.0000;
                a[1, 0] = 0.0237; a[1, 1] = -0.3108; a[1, 2] = 0.0134; a[1, 3] = -0.7215; a[1, 4] = -0.0028; a[1, 5] = -0.0054; a[1, 6] = 0.5208; a[1, 7] = 0.0000;
                a[2, 0] = 0.0468; a[2, 1] = 0.0055; a[2, 2] = -1.8954; a[2, 3] = 0.0000; a[2, 4] = 0.0588; a[2, 5] = 0.4562; a[2, 6] = 0.0000; a[2, 7] = 0.0000;
                a[3, 0] = 0.0000; a[3, 1] = 0.0000; a[3, 2] = 0.9985; a[3, 3] = 0.0000; a[3, 4] = 0.0000; a[3, 5] = 0.0000; a[3, 6] = 0.0000; a[3, 7] = 0.0532;
                a[4, 0] = 0.0207; a[4, 1] = 0.0002; a[4, 2] = -0.1609; a[4, 3] = 0.0380; a[4, 4] = -0.0351; a[4, 5] = -0.6840; a[4, 6] = 9.7697; a[4, 7] = 0.0995;
                a[5, 0] = 0.3397; a[5, 1] = 0.0236; a[5, 2] = -2.6449; a[5, 3] = 0.0000; a[5, 4] = -0.2715; a[5, 5] = -10.9759; a[5, 6] = 0.0000; a[5, 7] = -0.0203;
                a[6, 0] = 0.0000; a[6, 1] = 0.0000; a[6, 2] = -0.0039; a[6, 3] = 0.0000; a[6, 4] = 0.0000; a[6, 5] = 1.0000; a[6, 6] = 0.0000; a[6, 7] = 0.0737;
                a[7, 0] = 0.0609; a[7, 1] = 0.0089; a[7, 2] = -0.4766; a[7, 3] = 0.0000; a[7, 4] = -0.0137; a[7, 5] = -1.9367; a[7, 6] = 0.0000; a[6, 7] = -0.2743;
                Matrix matrixA = new Matrix(a);

               // матрица В
                double[,] b = new double[8, 4];
                b[0, 0] = 6.9417; b[0, 1] = -9.2860; b[0, 2] = 2.0164; b[0, 3] = 0.0000;
                b[1, 0] = -93.9179; b[1, 1] = -0.0020; b[1, 2] = -0.0003; b[1, 3] = 0.0000;
                b[2, 0] = 0.9554; b[2, 1] = 26.4011; b[2, 2] = -5.7326; b[2, 3] = 0.0000;
                b[3, 0] = 0.0000; b[3, 1] = 0.0000; b[3, 2] = 0.0000; b[3, 3] = 0.0000;
                b[4, 0] = -0.3563; b[4, 1] = -2.0164; b[4, 2] = -9.2862; b[4, 3] = 3.6770;
                b[5, 0] = 7.0476; b[5, 1] = -33.2120; b[5, 2] = -152.9537; b[5, 3] = -0.7358;
                b[6, 0] = 0.0000; b[6, 1] = 0.0000; b[6, 2] = 0.0000; b[6, 3] = 0.0000;
                b[7, 0] = 17.3054; b[7, 1] = -5.9909; b[7, 2] = -27.5911; b[7, 3] = -9.9111;
                Matrix matrixB = new Matrix(b);

                //матрица Р
                double[,] p = new double[8, 8];
                p[0, 0] = -0.4259;  p[0, 1] = -0.0314;  p[0, 2] = -0.1129;   p[0, 3] = 0.8474;  p[0, 4] =   0.0005;  p[0, 5] = -0.0006;  p[0, 6] = -0.0047; p[0, 7] = 0.0036;
                p[1, 0] = -0.0314;  p[1, 1] = -0.0162;  p[1, 2] = -0.0088;   p[1, 3] = 0.0615;  p[1, 4] = -0.0172;   p[1, 5] = 0.0042;   p[1, 6] = -0.0437; p[1, 7] = -0.0203;
                p[2, 0] = -0.1129;  p[2, 1] = -0.0088;  p[2, 2] = -0.0685;   p[2, 3] = 0.1427;  p[2, 4] = 0.0003;    p[2, 5] = -0.0001;  p[2, 6] = 0.0014;  p[2, 7] = 0.0007;
                p[3, 0] = 0.8474;   p[3, 1] = 0.0615;   p[3, 2] = 0.1427;    p[3, 3] = -4.6841; p[3, 4] = -0.0114;   p[3, 5] = 0.0039;   p[3, 6] = 0.0026;  p[3, 7] = -0.0216;
                p[4, 0] = 0.0005;   p[4, 1] = -0.0172;  p[4, 2] = 0.0003;    p[4, 3] = -0.0114; p[4, 4] = -0.4194;   p[4, 5] = 0.0413;   p[4, 6] = -0.8892; p[4, 7] = -0.1205;
                p[5, 0] = -0.0006;  p[5, 1] = 0.0042;   p[5, 2] = -0.0001;   p[5, 3] = 0.0039;  p[5, 4] = 0.0413;    p[5, 5] = -0.0131;  p[5, 6] = 0.0794;  p[5, 7] = 0.0290;
                p[6, 0] = -0.0047;  p[6, 1] = -0.0437;  p[6, 2] = 0.0014;    p[6, 3] = 0.0026;  p[6, 4] = -0.8892;   p[6, 5] = 0.0794;   p[6, 6] = -4.3526; p[6, 7] = -0.2919;
                p[7, 0] = 0.0036;   p[7, 1] = -0.0203;  p[7, 2] = 0.0007;    p[7, 3] = -0.0216; p[7, 4] = -0.1205;   p[7, 5] = 0.0290;   p[7, 6] = -0.2919; p[7, 7] = -0.1356;
                Matrix matrixP = new Matrix(p);

                //найти u = Q^-1 * B_transp * P
                double[,] u = new double[4, 8];
                Matrix matrixU = new Matrix(u);
                matrixU = Matrix.MultiplyMatr(matrixB.Transpose(), matrixP);

                //решить ДУ методом рунге-кутты
                //x. = (A - B * u) * x
               // Matrix A_Bu = Matrix.SubstractMatr(matrixA, Matrix.MultiplyMatr(matrixB, matrixU));
                
                //--------------------------------------------------------------------
                /*double[,] a_bu = new double[8, 8];
                a_bu[0, 0] = -9.8525; a_bu[0, 1] = 6.2016;   a_bu[0, 2] = 6.6444;   a_bu[0, 3] = 48.9770;   a_bu[0, 4] = -0.1899;   a_bu[0, 5] = 0.1046;    a_bu[0, 6] = -1.4934;   a_bu[0, 7] = -1.0150;
                a_bu[1, 0] = 5.3671;  a_bu[1, 1] = -91.6836; a_bu[1, 2] = 1.0572;   a_bu[1, 3] = 10.0715;   a_bu[1, 4] = 2.4153;    a_bu[1, 5] = 0.3698;    a_bu[1, 6] = 9.0737;    a_bu[1, 7] = 15.6964;
                a_bu[2, 0] = 26.8334; a_bu[2, 1] = 2.5691;   a_bu[2, 2] = -19.1282; a_bu[2, 3] = -113.4887; a_bu[2, 4] = 0.0079;    a_bu[2, 5] = -0.3789;   a_bu[2, 6] = 2.1324;    a_bu[2, 7] = -0.5724;
                a_bu[3, 0] = 0;       a_bu[3, 1] = 0;        a_bu[3, 2] = -0.9985;  a_bu[3, 3] = 0;         a_bu[3, 4] = 0;         a_bu[3, 5] = 0;         a_bu[3, 6] = 0;         a_bu[3, 7] = -0.0532;
                a_bu[4, 0] = -0.0043; a_bu[4, 1] = -0.6062;  a_bu[4, 2] = 0.2100;   a_bu[4, 3] = -0.4042;   a_bu[4, 4] = -10.1213;  a_bu[4, 5] = -7.7516;   a_bu[4, 6] = -51.8491;  a_bu[4, 7] = -0.9357;
                a_bu[5, 0] = 1.2357;  a_bu[5, 1] = -5.6212;  a_bu[5, 2] = 3.6595;   a_bu[5, 3] = -17.6950;  a_bu[5, 4] = -144.1614; a_bu[5, 5] = -120.2991; a_bu[5, 6] = -667.7497; a_bu[5, 7] = -69.8257;
                a_bu[6, 0] = 0;       a_bu[6, 1] = 0;        a_bu[6, 2] = 0.0039;   a_bu[6, 3] = 0;         a_bu[6, 4] = 0;         a_bu[6, 5] = -1;        a_bu[6, 6] = 0;         a_bu[6, 7] = -0.0737;
                a_bu[7, 0] = -0.3706; a_bu[7, 1] = 13.3685;  a_bu[7, 2] = 0.5333;   a_bu[7, 3] = -6.4430;   a_bu[7, 4] = -22.7538;  a_bu[7, 5] = -20.5748;  a_bu[7, 6] = -117.8396; a_bu[7, 7] = -23.6053;
                Matrix A_Bu = new Matrix(a_bu);*/

                //---------------------------

                //test
                //double[,] a_bu = new double[8, 8];

                //1
                /*
                a_bu[0, 0] = 1;
                for (int i = 1; i < 8; i++)
                {
                    for (int j = 1; j < 8; j++)
                    {
                        a_bu[i, j] = 0;
                        
                    }
                }*/
                

                //2
                /*
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (j == i) { a_bu[i, j] = 1; }
                        else { a_bu[i, j] = 0; }
                    }
                }*/
                 

                //3
               /*for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (j == 0) { a_bu[i, j] = 1; }
                        else { a_bu[i, j] = 0; }
                    }
                }
                */
                //Matrix A_Bu = new Matrix(a_bu);

                var Eigen = new double[8];
                Eigen[0] = -146.7;
                Eigen[1] = -94.4583;
                Eigen[2] = -32.3381;
                Eigen[3] = -9.70926;

                double[,] U_data = new double[8, 8];
                U_data[0, 0] = -0.0035;  U_data[0, 1] = 0.0731;  U_data[0, 2] = -0.3389; U_data[0, 3] = 0.0024;   U_data[0, 4] = -0.0298; U_data[0, 5] = 0.0805;  U_data[0, 6] = 0.7347;  U_data[0, 7] = 0.0;
                U_data[1, 0] = 0.0644;   U_data[1, 1] = -0.9811; U_data[1, 2] = -0.0064; U_data[1, 3] = -0.01623; U_data[1, 4] = -0.0018; U_data[1, 5] = 0.0318;  U_data[1, 6] = 0.0617;  U_data[1, 7] = -0.0032;
                U_data[2, 0] = -0.0043;  U_data[2, 1] = 0.0084;  U_data[2, 2] = 0.9401;  U_data[2, 3] = 0.0335;   U_data[2, 4] = 0.0784;  U_data[2, 5] = -0.0140; U_data[2, 6] = -0.1005; U_data[2, 7] = -0.6026;
                U_data[3, 0] = 0.0;      U_data[3, 1] = 0.0002;  U_data[3, 2] = 0.0290;  U_data[3, 3] = -0.0015;  U_data[3, 4] = -0.0165; U_data[3, 5] = 0.0175;  U_data[3, 6] = 0.1813;  U_data[3, 7] = 0.1129;
                U_data[4, 0] = -0.0591;  U_data[4, 1] = -0.0144; U_data[4, 2] = -0.0005; U_data[4, 3] = 0.3696;   U_data[4, 4] = -0.1366; U_data[4, 5] = 0.6381;  U_data[4, 6] = 0.1269;  U_data[4, 7] = -0.0536;
                U_data[5, 0] = -0.9782;  U_data[5, 1] = -0.0922; U_data[5, 2] = 0.0188;  U_data[5, 3] = 0.0889;   U_data[5, 4] = -0.6969; U_data[5, 5] = 0.0;     U_data[5, 6] = 0.0510;  U_data[5, 7] = 0.1142;
                U_data[6, 0] = -0.0068;  U_data[6, 1] = -0.0009; U_data[6, 2] = 0.0004;  U_data[6, 3] = 0.0022;   U_data[6, 4] = 0.1643;  U_data[6, 5] = -0.1510; U_data[6, 6] = -0.0421; U_data[6, 7] = -0.0127;
                U_data[7, 0] = -0.18797; U_data[7, 1] = 0.1526;  U_data[7, 2] = 0.0091;  U_data[7, 3] = -0.9099;  U_data[7, 4] = -0.0571; U_data[7, 5] = 0.1416;  U_data[7, 6] = 0.0112;  U_data[7, 7] = -0.0295;
                Matrix U = new Matrix(U_data);

                double[,] Uinv_ = new double[8, 8];
                Uinv_[0, 0] = 0.0001;  Uinv_[0, 1] = 0.0211;  Uinv_[0, 2] = 0.0268;  Uinv_[0, 3] = -0.1059; Uinv_[0, 4] = -0.9659; Uinv_[0, 5] = -0.8374; Uinv_[0, 6] = -4.5481; Uinv_[0, 7] = -0.4879;
                Uinv_[1, 0] = 0.0601;  Uinv_[1, 1] = -0.9842; Uinv_[1, 2] = 0.0129;  Uinv_[1, 3] = 0.0825;  Uinv_[1, 4] = -0.0784; Uinv_[1, 5] = -0.0837; Uinv_[1, 6] = -0.3713; Uinv_[1, 7] = 0.1351;
                Uinv_[2, 0] = -0.7870; Uinv_[2, 1] = -0.0486; Uinv_[2, 2] = 0.6697;  Uinv_[2, 3] = 3.5579;  Uinv_[2, 4] = -0.0169; Uinv_[2, 5] = -0.0051; Uinv_[2, 6] = -0.1354; Uinv_[2, 7] = 0.0176;
                Uinv_[3, 0] = 0.0147;  Uinv_[3, 1] = -0.16;   Uinv_[3, 2] = 0.0130;  Uinv_[3, 3] = -0.0929; Uinv_[3, 4] = 0.3421;  Uinv_[3, 5] = 0.1409;  Uinv_[3, 6] = 0.5491;  Uinv_[3, 7] = -0.9157;
                Uinv_[4, 0] = -0.1839; Uinv_[4, 1] = 0.0671;  Uinv_[4, 2] = -0.1072; Uinv_[4, 3] = 1.2305;  Uinv_[4, 4] = 1.4275;  Uinv_[4, 5] = -0.2332; Uinv_[4, 6] = 6.6193;  Uinv_[4, 7] = 0.5548;
                Uinv_[5, 0] = -0.3697; Uinv_[5, 1] = 0.0638;  Uinv_[5, 2] = -0.1477; Uinv_[5, 3] = 0.4431;  Uinv_[5, 4] = 0.6225;  Uinv_[5, 5] = -0.2161; Uinv_[5, 6] = 0.6975;  Uinv_[5, 7] = 0.6210;
                Uinv_[6, 0] = 1.0251;  Uinv_[6, 1] = 0.0718;  Uinv_[6, 2] = 0.3196;  Uinv_[6, 3] = 1.6344;  Uinv_[6, 4] = -0.1255; Uinv_[6, 5] = 0.0158;  Uinv_[6, 6] = 0.1434;  Uinv_[6, 7] = -0.0502;
                Uinv_[7, 0] = -1.4124; Uinv_[7, 1] = -0.1034; Uinv_[7, 2] = -0.6778; Uinv_[7, 3] = 5.4246;  Uinv_[7, 4] = 0.1673;  Uinv_[7, 5] = -0.0233; Uinv_[7, 6] = 0.6670;  Uinv_[7, 7] = 0.0479;
                Matrix Uinv = new Matrix(Uinv_);

                
                double[,] a_bu = new double[8, 8];
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 8; j++)
                    {
                        if (i == 4 && j == 4) { a_bu[i, j] = -2.34553; }
                        else if (i == 4 && j == 5) { a_bu[i, j] = -2.0924; }
                        else if (i == 5 && j == 4) { a_bu[i, j] = 2.0924; }
                        else if (i == 5 && j == 5) { a_bu[i, j] = -2.34553; }
                        else if (i == 6 && j == 6) { a_bu[i, j] = -1.88976; }
                        else if (i == 6 && j == 7) { a_bu[i, j] = -2.15015; }
                        else if (i == 7 && j == 6) { a_bu[i, j] = 2.15015; }
                        else if (i == 7 && j == 7) { a_bu[i, j] = -1.88976; }
                        else {a_bu[i, j] = 0;}
                    }
                }
                Matrix A_Bu = new Matrix(a_bu);
                

                //--------------------------------------------------------------------
                //рунге-кутт
                int n = 1000;
                rkDataLen = n;
                double t0 = 0, t1 = 5, dt = (t1-t0)/n;
                {
                    rkData = new double[n + 1,8];
                    var rkCalcs = new int[n + 1];
                    double t = t0;
             
                    // начальные значения
                    var X = new double[8];
                //    for (int j = 0; j < X.Length; j++) X[j] = (1 + (j % 3))*10;//50 * (j + 1);//100*(-1 + (j % 3));   !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    for (int j = 0; j < X.Length; j++) X[j] = x0[j,0];
                    //X[0] = -0.2; X[1] = -0.15; X[2] = -0.1; X[3] = -0.05; X[4] = 0.05; X[5] = 0.1; X[6] = 0.15; X[7] = 0.2;

                    var Y0 = new double[8];
                     
                    for (int i = 0; i < 8; i++)
                    {
                        double Y0_ = 0;
                        for (int j = 0; j < 8; j++)
                        {

                            Y0_ += Uinv_[i, j] * X[j];
                        }
                        Y0[i] = Y0_;

                    }

                    //Y0 = Matrix.MultiplyMatr(Uinv, X0);

                    var Y01 = new double[8];
                    var Y02 = new double[8];
                    for (int j = 0; j < 8; j++) { Y01[j] = 0; Y02[j] = 0; }
                    for (int j = 0; j < 4; j++) { Y01[j] = Y0[j]; Y02[4+j] = Y0[4+j]; }

                    for (int j = 0; j < X.Length; j++) rkData[0,j] = X[j];

                    // алгоритм
                    for (int k = 1; k <= n; k++, t += dt)
                    {
                        var f0 = f(Y02, A_Bu);
                        var Y1 = V_sV(Y02, 0.5 * dt, f0);
                        var f1 = f(Y1, A_Bu);
                        var Y2 = V_sV(Y02, 0.5 * dt, f1);
                        var f2 = f(Y2, A_Bu);
                        var Y3 = V_sV(Y02, dt, f2);
                        var f3 = f(Y3, A_Bu);
                        
                        var Y4 = V_sV(Y02,dt / 6, V_sV(V_sV(V_sV(f0, 2, f1), 2, f2), 1, f3));

                       //ответ
                        //part 1
                        var Y = new double[8];
                        for (int j = 0; j < 4; j++) 
                        { 
                            //1
                            Y[j] = Math.Exp(Eigen[j]*dt*k) * Y01[j]; 
                            //2
                            Y[4 + j] = Y4[4 + j]; 
                        }
                        //
                        //--------------------------
                      
                        //X = U * Y;

                        for (int i = 0; i < 8; i++)
                        {
                            double Y0_ = 0;
                            for (int j = 0; j < 8; j++)
                            {

                                Y0_ += U_data[i, j] * Y[j];
                            }
                            X[i] = Y0_;
                        }

                        //-----------------------------
                        Y02 = Y4;
                        for (int j = 0; j < X.Length; j++) rkData[k, j] = X[j];               
                    } 
                    // rkData !!!
                }

                double[,] S = new double[8, 8];
                Matrix matrixS = new Matrix(S);
                for(int i=0; i<8; i++)
                {
                    for(int j=0;j<8;j++)
                    {
                        if (i == j)
                        {
                            S[i, j] = 1;
                        }
                        else { S[i, j] = 0; }
                    }
                }

                var matrixS_U = Matrix.SubstractMatr(matrixS, Matrix.MultiplyMatr(matrixU.Transpose(), matrixU));

                //вычислить значение критерия    int    from 0 to 5    1/2 (x'Sx +u'Qu)     dt

                var I = 0.0;
                var N = n/2;
                var Dt = t1 / N;
                for (int k = 0; k < N; k++)
                {
                    var W = new double[8];
                    for (int i = 0; i < 8; i++)
                    {

                        double Y0_ = 0;
                        for (int j = 0; j < 8; j++)
                        {

                            Y0_ += matrixS_U.matrixBase[i, j] * rkData[k*2, j];
                        }

                        W[i] = Y0_;
                    }

                    for (int i = 0; i < 8; i++)
                    {
                        I += Dt * rkData[k * 2, i] * W[i]; 
                    }
                }
                
                pictureBox2.Refresh();
                textBox2.Text = I.ToString();
            }


            else if (comboBox1.SelectedIndex == 1)
            {
                // матрица А
                double[,] a = new double[8, 8];
                //for (int i = 0; i < 8; ++ i) a[i, 0] = 1;
                a[0, 0] = -0.0082; a[0, 1] = 0.0254;  a[0, 2] = -0.0685; a[0, 3] = -9.7868; a[0, 4] = -0.0158; a[0, 5] = -0.1480;  a[0, 6] = 0.0000; a[0, 7] = 0.0000;
                a[1, 0] = -0.1723; a[1, 1] = -0.4346; a[1, 2] = 10.4965; a[1, 3] = -0.6792; a[1, 4] = -0.0150; a[1, 5] = -0.1044;  a[1, 6] = 0.4545; a[1, 7] = 0.0000;
                a[2, 0] = 0.0417;  a[2, 1] = 0.0157;  a[2, 2] = -2.0012; a[2, 3] = 0.0000;  a[2, 4] = 0.0482;  a[2, 5] = 0.4441;   a[2, 6] = 0.0000; a[2, 7] = 0.0000;
                a[3, 0] = 0.0000;  a[3, 1] = 0.0000;  a[3, 2] = 0.9989;  a[3, 3] = 0.0000;  a[3, 4] = 0.0000;  a[3, 5] = 0.0000;   a[3, 6] = 0.0000; a[3, 7] = 0.0464;
                a[4, 0] = 0.0173;  a[4, 1] = 0.0161;  a[4, 2] = -0.1435; a[4, 3] = 0.0311;  a[4, 4] = -0.0604; a[4, 5] = 0.0308;   a[4, 6] = 9.7761; a[4, 7] = -10.1108;
                a[5, 0] = 0.1531;  a[5, 1] = 0.2739;  a[5, 2] = -2.4044; a[5, 3] = 0.0000;  a[5, 4] = -0.2439; a[5, 5] = -10.9208; a[5, 6] = 0.0000; a[5, 7] = -0.0793;
                a[6, 0] = 0.0000;  a[6, 1] = 0.0000;  a[6, 2] = -0.0032; a[6, 3] = 0.0000;  a[6, 4] = 0.0000;  a[6, 5] = 1.0000;   a[6, 6] = 0.0000; a[6, 7] = 0.0694;
                a[7, 0] = 0.0037;  a[7, 1] = 0.0455;  a[7, 2] = -0.3753; a[7, 3] = 0.0000;  a[7, 4] = 0.0025;  a[7, 5] = -1.9201;  a[7, 6] = 0.0000; a[6, 7] = -0.4404;
                Matrix matrixA = new Matrix(a);

                // матрица В
                double[,] b = new double[8, 4];
                b[0, 0] = 5.6326;   b[0, 1] = -8.9083;  b[0, 2] = 2.0273;    b[0, 3] = 0.0000;
                b[1, 0] = -89.9908; b[1, 1] = -6.0809;  b[1, 2] = 0.0010;    b[1, 3] = 0.0000;
                b[2, 0] = 3.8558;   b[2, 1] = 26.6794;  b[2, 2] = -5.7663;   b[2, 3] = 0.0000;
                b[3, 0] = 0.0000;   b[3, 1] = 0.0000;   b[3, 2] = 0.0000;    b[3, 3] = 0.0000;
                b[4, 0] = 0.1249;   b[4, 1] = -2.0098;  b[4, 2] = -9.3275;   b[4, 3] = 3.4515;
                b[5, 0] = 13.2029;  b[5, 1] = -32.8252; b[5, 2] = -153.5913; b[5, 3] = -0.6907;
                b[6, 0] = 0.0000;   b[6, 1] = 0.0000;   b[6, 2] = 0.0000;    b[6, 3] = 0.0000;
                b[7, 0] = 16.5240;  b[7, 1] = -5.9080;  b[7, 2] = -27.5007;  b[7, 3] = -9.302;
                Matrix matrixB = new Matrix(b);

                //матрица Р 
                double[,] p = new double[8, 8];
                p[0, 0] = -0.4286; p[0, 1] = -0.0264; p[0, 2] = -0.1134; p[0, 3] = -0.8544; p[0, 4] = 0.0101; p[0, 5] = -0.0052; p[0, 6] = -0.0176; p[0, 7] = 0.0263;
                p[1, 0] = -0.0267; p[1, 1] = -0.0184; p[1, 2] = -0.0079; p[1, 3] = -0.0416; p[1, 4] = -0.0209; p[1, 5] = 0.0073; p[1, 6] = 0.0282; p[1, 7] = -0.0373;
                p[2, 0] = -0.1134; p[2, 1] = -0.0079; p[2, 2] = -0.0733; p[2, 3] = -0.1442; p[2, 4] = 0.0048; p[2, 5] = -0.0019; p[2, 6] = -0.0072; p[2, 7] = 0.0099;
                p[3, 0] = -0.8544; p[3, 1] = -0.0416; p[3, 2] = -0.1442; p[3, 3] = -4.7441; p[3, 4] = 0.0303; p[3, 5] = -0.0218; p[3, 6] = -0.0543; p[3, 7] = 0.1123;
                p[4, 0] = 0.0101; p[4, 1] = -0.0209; p[4, 2] = 0.0048; p[4, 3] = 0.0303; p[4, 4] = -0.1997; p[4, 5] = 0.0395; p[4, 6] = 0.1889; p[4, 7] = -0.1670;
                p[5, 0] = -0.0052; p[5, 1] = 0.0073; p[5, 2] = -0.0019; p[5, 3] = -0.0218; p[5, 4] = 0.0395; p[5, 5] = -0.0191; p[5, 6] = -0.0393; p[5, 7] = 0.0581;
                p[6, 0] = -0.0176; p[6, 1] = 0.0282; p[6, 2] = -0.0072; p[6, 3] = -0.0543; p[6, 4] = 0.1889; p[6, 5] = -0.0393; p[6, 6] = -1.5259; p[6, 7] = 0.2139;
                p[7, 0] = 0.0263; p[7, 1] = -0.0373; p[7, 2] = 0.0099; p[7, 3] = 0.1123; p[7, 4] = -0.1670; p[7, 5] = 0.0581; p[7, 6] = 0.2139; p[7, 7] = -0.2849;
                Matrix matrixP = new Matrix(p);

                //найти u = Q^-1 * B_transp * P
                double[,] u = new double[4, 8];
                Matrix matrixU = new Matrix(u);
                matrixU = Matrix.MultiplyMatr(matrixB.Transpose(), matrixP);

                //решить ДУ методом рунге-кутты
                //x. = (A - B * u) * x
                Matrix A_Bu = Matrix.SubstractMatr(matrixA, Matrix.MultiplyMatr(matrixB, matrixU));
                




                //рунге-кутт

                int n = 100000;
                rkDataLen = n;
                double t0 = 0, t1 = 1, dt = (t1 - t0) / n;
                {
                    rkData = new double[n + 1, 8];
                    var rkCalcs = new int[n + 1];
                    double t = t0;

                    // начальные значения
                    var X = new double[8];
                    for (int j = 0; j < X.Length; j++) X[j] = (10 + (j % 3))/50;//50 * (j + 1);//100*(-1 + (j % 3));
                    //for (int j = 0; j < X.Length; j++) X[j] = x0[j,0];
                    for (int j = 0; j < X.Length; j++) rkData[0, j] = X[j];

                    // алгоритм
                    for (int k = 1; k <= n; k++, t += dt)
                    {
                        var f0 = f(X, A_Bu);
                        var Y1 = V_sV(X, 0.5 * dt, f0);
                        var f1 = f(Y1, A_Bu);
                        var Y2 = V_sV(X, 0.5 * dt, f1);
                        var f2 = f(Y2, A_Bu);
                        var Y3 = V_sV(X, dt, f2);
                        var f3 = f(Y3, A_Bu);

                        var Y4 = V_sV(X, dt / 6, V_sV(V_sV(V_sV(f0, 2, f1), 2, f2), 1, f3));

                        //ответ
                        X = Y4;
                        for (int j = 0; j < X.Length; j++) rkData[k, j] = X[j];
                    }
                    // rkData !!!
                }

                pictureBox2.Refresh();


            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

 

        //построение графиков
        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {

            int H = -100;
            PointF point1 = new PointF(55.0F, 0.0F);
            PointF point2 = new PointF(50.0F, 8.6F);
            PointF point3 = new PointF(60.0F, 8.6F);
            PointF[] traingle = {point1, point2, point3};

            PointF point11 = new PointF(pictureBox2.Width, pictureBox2.Height + H);
            PointF point21 = new PointF(pictureBox2.Width - 8.6F, pictureBox2.Height + H + 5);
            PointF point31 = new PointF(pictureBox2.Width - 8.6F, pictureBox2.Height + H - 5);
            PointF[] traingle1 = { point11, point21, point31 };

            //оси
            var pen0 = new Pen(Color.Black);
            SolidBrush blBrush = new SolidBrush(Color.Black);
            //стрелка
            e.Graphics.DrawPolygon(pen0, traingle1);
            e.Graphics.FillPolygon(blBrush, traingle1);
            //x
            e.Graphics.DrawLine(pen0, 0, pictureBox2.Height + H, pictureBox2.Width, pictureBox2.Height + H);
            //стрелка
            e.Graphics.DrawPolygon(pen0, traingle);
            e.Graphics.FillPolygon(blBrush, traingle);
            //y
            e.Graphics.DrawLine(pen0, 55, 0, 55, pictureBox2.Height);



            if (this.rkData == null)
                return;
            //
            var pen1 = new Pen(Color.Magenta);

            var rkDataLen = this.rkDataLen/10;
            var rkData = new double[rkDataLen + 1, 8];
            for (int j = 0; j <= rkDataLen; j++)
                for (int i = 0; i < 8; i++) rkData[j, i] = 1000*this.rkData[10 * j, i];

            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = (50 + 5 * (k + 1));
                double y1 = pictureBox2.Height + H - rkData[k, 0];
                double y2 = pictureBox2.Height + H - rkData[k+1, 0];
                e.Graphics.DrawLine(pen1, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen2 = new Pen(Color.Red);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 1];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 1];
                e.Graphics.DrawLine(pen2, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen3 = new Pen(Color.Green);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 2];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 2];
                e.Graphics.DrawLine(pen3, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen4 = new Pen(Color.Indigo);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 3];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 3];
              e.Graphics.DrawLine(pen4, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen5 = new Pen(Color.Lavender);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 4];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 4];
               e.Graphics.DrawLine(pen5, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen6 = new Pen(Color.Orange);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 5];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 5];
                e.Graphics.DrawLine(pen6, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen7 = new Pen(Color.Purple);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 6];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 6];
                e.Graphics.DrawLine(pen7, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
            }

            var pen8 = new Pen(Color.Yellow);
            for (int k = 1; k < rkDataLen; k++)
            {
                double x1 = 50 + 5 * k, x2 = 50 + 5 * (k + 1);
                double y1 = pictureBox2.Height + H - rkData[k, 7];
                double y2 = pictureBox2.Height + H - rkData[k + 1, 7];
                e.Graphics.DrawLine(pen8, new Point((int)x1, (int)y1), new Point((int)x2, (int)y2));
                
            }
        }








    }
}
